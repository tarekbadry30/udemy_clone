<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 >
        <?php echo e(translate('coursesList')); ?>

        <br>
        <?php if(isset($tag)): ?>
        <?php echo e(translate('tag')); ?> : <?php echo e($tag->name); ?>

        <?php elseif(isset($category)): ?>
        <?php echo e(translate('category')); ?> : <?php echo e($category->name); ?>

        <?php endif; ?>
    </h2>
    <div class="row courses_container">
    </div>
    <div class="text-center position">
        <img src="<?php echo e(asset('img/loading.gif')); ?>" class="loading-spinner img-fluid">
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        let page=1;
        let lastPage=1;
        let canReload=true;
        $(document).ready(function () {
            getCourses(page);
            $(window).scroll(function() {
                var windowsHeight = $(document).height() - $(window).height();
                var currentScroll = $(document).scrollTop();
                //if I scroll more than 80%
                if( ((currentScroll *100) / windowsHeight) > 80){
                    if(canReload&& $('.search-input').val().trim().length<1){
                        page++;
                        getCourses(page);
                    }
                }
            });
            $(document).on('keyup','.search-input',function () {
                $('.courses_container').html(``);
                if($(this).val().trim().length>0)
                    searchCourses($(this).val());
                else{
                    page=1;
                    getCourses(page);
                }
            })

        });
        function getCourses(page) {
            $('.courses_title_container').text('<?php echo e(translate('searchResult')); ?>');
            showLoadingSpinner();
            if(lastPage>=page)
                $.ajax({
                    url: "<?php echo e(route('courses.listAjax')); ?>",
                    data:{
                        "_token":"<?php echo e(csrf_token()); ?>",
                        'page':page,
                        <?php if(isset($tag)): ?>
                        'tag_name' : '<?php echo e($tag->name); ?>',
                        <?php elseif(isset($category)): ?>
                        'category_id':<?php echo e($category->id); ?>,
                        <?php endif; ?>
                    },
                    type:'post',
                    success: function(result){
                        let courses=result.list.data;
                        lastPage=result.list.last_page;
                        if(courses.length<1&&page==1)
                            $('.courses_container').html(`
                                <h3 class="text-center"><?php echo e(translate('noData')); ?></h3>
                            `);
                        else
                            courses.forEach(function (course) {
                                $('.courses_container').append(`
                                    <div class="col-lg-3 col-md-4 col-sm-6 col-12 p-1">
                                        <div class="course_item">
                                            <div class="image_container">
                                                <img src="/${course.image}" class="img-fluid course_img">
                                            </div>
                                            <div class="details_container">
                                                <a href="<?php echo e(route('courses.details')); ?>?course_id=${course.id}">
                                                    <h3 class="course_name">${course.name}</h3>
                                                </a>
                                                <p class="course_details">${course.description}</p>
                                                <div class="rating d-flex justify-content-around">
                                                    <div class="">${course.rating+ ' ' +getRate(course.rating)}</div>
                                                    <div class=""><i class="fa fa-eye"></i> ${ course.views}</div>
                                                </div>
                                                <h5  class="hours"><i class="far fa-clock"></i>  ${course.hours} <?php echo e(translate('hours')); ?></h5>
                                            </div>
                                        </div>
                                    </div>
                                `);
                            });
                        hideLoadingSpinner();
                    }
                });
            else
                hideLoadingSpinner();
        }
        function getRate(rate) {
            let output='';
            for(i=1;i<6;i++){
                if(rate>=i){ //full or half star
                    output+=`<i class="fas fa-star"></i>`;
                }else{
                    output+=`<i class="far fa-star"></i>`;
                }
            }
            return output;
        }
        function searchCourses(text) {
            showLoadingSpinner();
            $.ajax({
                url: "<?php echo e(route('courses.search')); ?>",
                data:{
                    "_token":"<?php echo e(csrf_token()); ?>",
                    'text':text
                },
                type:'post',
                success: function(result){
                    let courses=result.list;
                    $('.courses_container').html(``);
                    if(courses.length<1)
                        $('.courses_container').html(`
                            <h3 class="text-center"><?php echo e(translate('noData')); ?></h3>
                        `);
                    else
                        courses.forEach(function (course) {
                            $('.courses_container').append(`
                                <div class="col-lg-3 col-md-4 col-sm-6 col-12 p-1">
                                    <div class="course_item">
                                        <div class="image_container">
                                            <img src="/${course.image}" class="img-fluid course_img">
                                        </div>
                                        <div class="details_container">
                                            <a href="<?php echo e(route('courses.details')); ?>?course_id=${course.id}">
                                                <h3 class="course_name">${course.name}</h3>
                                            </a>
                                            <p class="course_details">${course.description}</p>
                                            <div class="rating d-flex justify-content-around">
                                                <div class="">${course.rating+ ' ' +getRate(course.rating)}</div>
                                                <div class=""><i class="fa fa-eye"></i> ${ course.views}</div>
                                            </div>
                                            <h5  class="hours"><i class="far fa-clock"></i> ${course.hours} <?php echo e(translate('hours')); ?></h5>
                                        </div>
                                    </div>
                                </div>
                            `);
                        });
                    hideLoadingSpinner();
                }
            });
        }

        function showLoadingSpinner() {
            canReload=false;
            $(".loading-spinner").show()
        }
        function hideLoadingSpinner() {
            canReload=true;
            $(".loading-spinner").hide()
        }

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\e3ml_Busniss_task\resources\views/courses/list.blade.php ENDPATH**/ ?>