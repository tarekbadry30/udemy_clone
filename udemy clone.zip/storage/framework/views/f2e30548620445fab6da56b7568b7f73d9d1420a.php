<?php $__env->startSection('content'); ?>
<div class="container course_details_page">
    <div class="row course_details">
        <div class="image_container col-md-4">
            <img src="<?php echo e(asset($course->image)); ?>" class="img-fluid course_img">
        </div>
        <div class=" details_container col-md-7">
            <h1>
                <?php echo e($course->name); ?>

            </h1>
            <p><?php echo e($course->description); ?></p>
            <div class="rating d-flex ">
                <span class="rating-stars col-4"></span>
                <div class="text-left col-3"><i class="fa fa-eye"></i> <?php echo e($course->views); ?></div>
            </div>
            <h5  class="hours"><i class="far fa-clock"></i> <?php echo e($course->hours); ?> <?php echo e(translate('hours')); ?></h5>
            <?php if($course->tags->count()>0): ?>
            <hr>
            <div class="tags-container">

                <h4 class="font-weight-bold" ><?php echo e(translate('tags')); ?></h4>
                <?php $__currentLoopData = $course->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('courses.list',['tag_name'=>$tag->name])); ?>" class="px-1"># <?php echo e($tag->name); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php endif; ?>
            <?php if(auth()->guard()->check()): ?>
            <hr>
            <div class="student-status">

            </div>
            <?php endif; ?>
        </div>
        <div class="text-center position">
            <img src="<?php echo e(asset('img/loading.gif')); ?>" class="loading-spinner img-fluid">
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        $(document).ready(function () {
            showLoadingSpinner();
            $(".search-input").hide();
            $(".rating-stars").html(getRate(<?php echo e($course->rating); ?>));
            hideLoadingSpinner();
            checkStatus(<?php echo e($course->getStudentStatus()); ?>);
            $(document).on('click','.rate-icon',function () {
                let ratingValue = $(this).attr('value');
                giveRate(ratingValue);
            });
            $(document).on('click','.join-btn',function () {
                joinOrLeaveCourse();
            });
        });
        function getRate(rate) {
            let output=`${rate} `;
            for(i=1;i<6;i++){
                if(rate>=i){ //full or half star
                    output+=`<i value="${i}" class="<?php if(auth()->guard()->check()): ?> rate-icon <?php endif; ?> fas fa-star"></i>`;
                }else{
                    output+=`<i value="${i}" class="<?php if(auth()->guard()->check()): ?> rate-icon <?php endif; ?> far fa-star"></i>`;
                }
            }
            return output;
        }
        function giveRate(rate) {
            showLoadingSpinner();
            $.ajax({
                    url: "<?php echo e(route('courses.giveRate')); ?>",
                    data:{
                        "_token":"<?php echo e(csrf_token()); ?>",
                        'rate':rate,
                        'course_id':<?php echo e($course->id); ?>

                    },
                    type:'post',
                    success: function(data){
                        hideLoadingSpinner();
                        if(data.errorNum==200){
                            Swal.fire({
                                title: `${data.msg}`,
                                icon: "success",
                                showConfirmButton: true,
                                timer:1000,
                                confirmButtonText: '<?php echo e(translate('ok')); ?>',
                            });
                        }
                        else if(data.errorNum==400){
                            let outputMessage='';
                            let errorMessage=data.msg;
                            for(i=0;i<data.errors.length;i++)
                                outputMessage+=`${data.errors[i]} \n  `;
                            Swal.fire({
                                title: `${errorMessage}`,
                                icon: "error",
                                text: `${outputMessage}`,
                                showConfirmButton: true,
                                confirmButtonText: '<?php echo e(translate('ok')); ?>',
                            });
                        }
                        else{
                            Swal.fire({
                                title: `${data.msg}`,
                                icon: "error",
                                //timer: 1300,
                                showConfirmButton: true,
                                confirmButtonText: '<?php echo e(translate('ok')); ?>',
                            });
                        }
                        $(".rating-stars").html(getRate(data.newRate));
                    }
                });

        }
        function joinOrLeaveCourse() {
            showLoadingSpinner();
            $.ajax({
                    url: "<?php echo e(route('courses.join')); ?>",
                    data:{
                        "_token":"<?php echo e(csrf_token()); ?>",
                        'course_id':<?php echo e($course->id); ?>

                    },
                    type:'post',
                    success: function(data){
                        hideLoadingSpinner();
                        if(data.errorNum==200){
                            Swal.fire({
                                title: `${data.msg}`,
                                icon: "success",
                                showConfirmButton: true,
                                confirmButtonText: '<?php echo e(translate('ok')); ?>',
                            });
                            checkStatus(data.newStatus);
                        }
                        else if(data.errorNum==400){
                            let outputMessage='';
                            let errorMessage=data.msg;
                            for(i=0;i<data.errors.length;i++)
                                outputMessage+=`${data.errors[i]} \n  `;
                            Swal.fire({
                                title: `${errorMessage}`,
                                icon: "error",
                                text: `${outputMessage}`,
                                showConfirmButton: true,
                                confirmButtonText: '<?php echo e(translate('ok')); ?>',
                            });
                        }
                        else{
                            Swal.fire({
                                title: `${data.msg}`,
                                icon: "error",
                                //timer: 1300,
                                showConfirmButton: true,
                                confirmButtonText: '<?php echo e(translate('ok')); ?>',
                            });
                        }
                    }
                });
        }

        function checkStatus(status) {
            if(status)
            $(".student-status").html(`
                <p><?php echo e(translate('youAreJoined')); ?>

                </p>
                    <button class="btn join-btn btn-outline-danger"> <i class="text-dark fas fa-window-close"></i> <?php echo e(translate('leave')); ?></button>

            `);
        else
            $(".student-status").html(`
                <p><?php echo e(translate('youAreNotJoined')); ?>

                </p>
                   <button class="btn join-btn btn-outline-success"> <i class="text-dark fas fa-user-graduate"></i> <?php echo e(translate('join')); ?></button>
            `);
        }
        function showLoadingSpinner() {
            $(".loading-spinner").show()
        }
        function hideLoadingSpinner() {
            $(".loading-spinner").hide()
        }

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\e3ml_Busniss_task\resources\views/courses/details.blade.php ENDPATH**/ ?>