<?php $__env->startSection('content'); ?>
<div class="container dashboard">
    <h2 >
        <?php echo e(translate('dashboard')); ?>

        <br>
    </h2>
    <div class="row dashboard_container">
        <div class="col-md-4 col-sm-6 col-12 ">
            <div class="card_item">
                <a href="<?php echo e(route('category.all')); ?>">
                    <h5 class="text-center"><?php echo e(translate('categories')); ?></h5>
                    <h6><?php echo e($categoryCount); ?></h6>
                </a>
            </div>
        </div>
        <div class="col-md-4 col-sm-6 col-12 ">
            <div class="card_item">
                <a href="<?php echo e(route('courses.all')); ?>">
                    <h5 class="text-center"><?php echo e(translate('courses')); ?></h5>
                    <h6><?php echo e($coursesCount); ?></h6>
                </a>
            </div>
        </div>
        <div class="col-md-4 col-sm-6 col-12 ">
            <div class="card_item">
                <a href="<?php echo e(route('tags.list')); ?>">
                    <h5 class="text-center"><?php echo e(translate('tags')); ?></h5>
                    <h6><?php echo e($tagsCount); ?></h6>
                </a>
            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        $(document).ready(function () {
            $(".search-input").hide();

        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\e3ml_Busniss_task\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>