<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header row">
                        <div class="col-8 <?php echo e(textAlign()); ?>">
                            <h1 class="page-title reload-btn">
                                <?php echo e(translate('categoriesList')); ?>

                            </h1>
                        </div>
                        <div class="col-3">
                            <button
                                class="new-category btn btn-outline-success"
                                item_id="<?php echo e(isset($parent)?$parent->id:''); ?>"
                                item_title="<?php echo e(isset($parent)?$parent->title:''); ?>"
                                data-toggle="modal" data-target="#new-category-modal">
                                <?php echo e(translate('newCat')); ?>

                            </button>
                        </div>
                    </div>

                    <div class="card-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>

                        <div class="table-container">
                            <table class="table table-bordered table-hover">
                                <thead>
                                <tr>
                                    <th>#</th>
                                    <th><?php echo e(translate('name')); ?></th>
                                    <th><?php echo e(translate('status')); ?></th>
                                    <th><?php echo e(translate('courses')); ?></th>
                                    <th><?php echo e(translate('control')); ?></th>
                                </tr>
                                </thead>
                                <tbody class="t-body">
                                <tr>
                                    <td colspan="5"><?php echo e(translate('noData')); ?></td>
                                </tr>
                                </tbody>
                            </table>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal"  id="new-category-modal" >
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content" >

                <!-- Modal Header -->
                <div class="modal-header" dir="<?php echo e(app()->getLocale()=='ar'?'rtl':'ltr'); ?>">
                    <h5 class="modal-title"><?php echo e(translate('newCat')); ?></h5>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>

                <form class="insert-form ajax-form" action="<?php echo e(route('category.insert')); ?>" method="post">
                    <div class="modal-body">
                        <?php echo csrf_field(); ?>
                        <div class="form-group <?php echo e(textAlign()); ?>">
                            <label for="new-category-title"><?php echo e(translate('title')); ?></label>
                            <input required type="text" class="form-control" id="new-category-title" name="title">
                        </div>
                        <div class="form-group <?php echo e(textAlign()); ?>">
                            <label ><?php echo e(translate('parentCat')); ?></label>
                            <input type="text" name="parent_name" class="parent_name form-control" readonly >
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo e(translate('cancel')); ?></button>
                        <button type="submit" class="btn btn-success"><?php echo e(translate('insert')); ?></button>
                    </div>
                </form>


            </div>
        </div>
    </div>
    <div class="modal"  id="edit-item-modal" >
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content" >
                <!-- Modal Header -->
                <div class="modal-header" dir="<?php echo e(app()->getLocale()=='ar'?'rtl':'ltr'); ?>">
                    <h5 class="modal-title"><?php echo e(translate('editCategory')); ?></h5>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>

                <form class="update-form ajax-form" action="<?php echo e(route('category.update')); ?>" method="post">
                    <div class="modal-body">
                        <?php echo csrf_field(); ?>
                        <div class="form-group <?php echo e(textAlign()); ?>">
                            <label for="new-category-title"><?php echo e(translate('title')); ?></label>
                            <input required type="text" class="form-control item-title" id="item-title" name="title">
                            <input required type="hidden" class="form-control item-id" id="item-id" name="category_id">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo e(translate('cancel')); ?></button>
                        <button type="submit" class="btn btn-success"><?php echo e(translate('update')); ?></button>
                    </div>
                </form>


            </div>
        </div>
    </div>
    <div class="modal"  id="delete-item-modal" >
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content" >
                <!-- Modal Header -->
                <div class="modal-header" dir="<?php echo e(pageDirection()); ?>">
                    <h5 class="modal-title"><?php echo e(translate('deleteCategory')); ?></h5>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>

                <form class="update-form ajax-form" action="<?php echo e(route('category.delete')); ?>" method="post">
                    <div class="modal-body">
                        <?php echo csrf_field(); ?>
                        <h5 class="text-center text-danger">
                            <?php echo e(translate('deleteConfirmMsg')); ?>

                        </h5>
                        <input required type="hidden" class="form-control item-id" id="item-id" name="category_id">
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo e(translate('cancel')); ?></button>
                        <button type="submit" class="btn btn-success"><?php echo e(translate('confirm')); ?></button>
                    </div>
                </form>


            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        $(document).ready(function () {
            getCategories();
            $(document).on('click','.new-category',function () {
                $('#new-category-modal .parent_name').val($(this).attr("item_title"));
            });
            $(document).on('click','.reload-btn',function () {
                getCategories();
            });
            $(document).on('click','.edit-item',function () {
                $('#edit-item-modal .item-id').val($(this).attr("item_id"));
                $('#edit-item-modal .item-title').val($(this).attr("item_title"));
            });
            $(document).on('click','.delete-item',function () {
                $('#delete-item-modal .item-id').val($(this).attr("item_id"));
            });
        });
        function getCategories() {
            $.ajax({
                url: "<?php echo e(route('category.listAjax')); ?>",
                data:{
                    "_token":"<?php echo e(csrf_token()); ?>",
                },
                type:'post',
                success: function(result){
                    let categories=result.data.categories;
                    let output='';
                    if(categories.length<1)
                        output=`
                        <tr>
                            <td colspan="5"><?php echo e(translate('noData')); ?></td>
                        </tr>
                    `;
                    else

                        categories.forEach(function (category,index) {
                            output+=`
                        <tr>
                            <td>${index+1}</td>
                            <td>${category.title}</td>
                            <td>${category.active?'<?php echo e(translate('disabled')); ?>':'<?php echo e(translate('disabled')); ?>'}</td>
                            <td>${category.postsCount}</td>
                            <td>
                                <button
                                    class="btn btn-outline-success new-category"
                                    data-toggle="modal" data-target="#new-category-modal"
                                    item_id="${category.id}"
                                    item_title="${category.title}"
                                    index="${index}">
                                    <?php echo e(translate('newCat')); ?>

                            </button>

                            <button
                                class="btn btn-outline-primary edit-item"
                                data-toggle="modal" data-target="#edit-item-modal"
                                item_id="${category.id}"
                                    item_title="${category.title}"
                                    index="${index}">
                                    <?php echo e(translate('edit')); ?>

                            </button>

                            <button
                                class="btn btn-outline-danger delete-item"
                                data-toggle="modal" data-target="#delete-item-modal"
                                index="${index}" item_id="${category.id}">
                                    <?php echo e(translate('delete')); ?>

                            </button>
                        </td>
                    </tr>
`;
                        });
                    $('.t-body').html(output);
                }
            });
        }

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\e3ml_Busniss_task\resources\views/category/index.blade.php ENDPATH**/ ?>